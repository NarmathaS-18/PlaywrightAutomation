import fs from 'fs';
import path from 'path';


// ============================================================
// SCREENSHOT UTILITY
// ============================================================

export async function captureScreen(
    page,
    testInfo,
    screenName
) {

    await testInfo.attach(
        `SCREEN - ${screenName}`,
        {
            body: await page.screenshot({
                fullPage: true
            }),

            contentType: 'image/png'
        }
    );
}


// ============================================================
// CUSTOM HTML REPORTER
// ============================================================

class CustomHTMLReporter {

    constructor() {

        this.results = [];

        this.reportFolder =
            path.resolve('custom-report');

        this.attachmentFolder =
            path.join(
                this.reportFolder,
                'attachments'
            );

        fs.mkdirSync(
            this.attachmentFolder,
            {
                recursive: true
            }
        );
    }


    // ========================================================
    // CALLED AFTER EVERY TEST
    // ========================================================

    onTestEnd(test, result) {

        // -----------------------------------------------
        // TEST TITLE
        // -----------------------------------------------

        const testTitle =
            test.title;


        // -----------------------------------------------
        // SCENARIO
        // -----------------------------------------------

        const titlePath =
            test.titlePath();

        let scenario = '';


        if (titlePath.length >= 2) {

            scenario =
                titlePath[
                    titlePath.length - 2
                ];
        }


        // -----------------------------------------------
        // STATUS
        // -----------------------------------------------

        let status;


        if (result.status === 'passed') {

            status = 'PASSED';

        } else if (
            result.status === 'failed' ||
            result.status === 'timedOut'
        ) {

            status = 'FAILED';

        } else if (
            result.status === 'skipped'
        ) {

            status = 'SKIPPED';

        } else {

            status =
                result.status.toUpperCase();
        }


        // -----------------------------------------------
        // SCREENSHOTS
        // -----------------------------------------------

        const screenshots = [];


        // -----------------------------------------------
        // VIDEO
        // -----------------------------------------------

        let video = null;


        for (
            const attachment
            of result.attachments
        ) {


            // SCREENSHOT

            if (
                attachment.contentType ===
                'image/png' &&
                attachment.path
            ) {

                const screenshot =
                    this.copyAttachment(
                        attachment,
                        test,
                        'screenshot'
                    );

                screenshots.push(
                    screenshot
                );
            }


            // VIDEO

            if (
                attachment.contentType ===
                'video/webm' &&
                attachment.path
            ) {

                video =
                    this.copyAttachment(
                        attachment,
                        test,
                        'video'
                    );
            }
        }


        // -----------------------------------------------
        // ERROR
        // -----------------------------------------------

        let error = '';


        if (result.error) {

            error =
                result.error.message || '';
        }


        // -----------------------------------------------
        // SAVE RESULT
        // -----------------------------------------------

        this.results.push({

            testTitle,

            scenario,

            status,

            screenshots,

            video,

            duration:
                result.duration,

            error
        });
    }


    // ========================================================
    // COPY SCREENSHOT / VIDEO
    // ========================================================

    copyAttachment(
        attachment,
        test,
        type
    ) {

        const extension =
            type === 'screenshot'
                ? '.png'
                : '.webm';


        const safeTestName =
            test.title
                .replace(
                    /[^a-zA-Z0-9-_]/g,
                    '_'
                );


        const fileName =
            `${safeTestName}-${type}-${Date.now()}${extension}`;


        const destination =
            path.join(
                this.attachmentFolder,
                fileName
            );


        fs.copyFileSync(
            attachment.path,
            destination
        );


        return {
            name: attachment.name,
            path:
                `attachments/${fileName}`
        };
    }


    // ========================================================
    // CREATE HTML REPORT
    // ========================================================

    async onEnd() {

        const total =
            this.results.length;


        const passed =
            this.results.filter(
                result =>
                    result.status === 'PASSED'
            ).length;


        const failed =
            this.results.filter(
                result =>
                    result.status === 'FAILED'
            ).length;


        const skipped =
            this.results.filter(
                result =>
                    result.status === 'SKIPPED'
            ).length;


        // -----------------------------------------------
        // CREATE TABLE
        // -----------------------------------------------

        const rows =
            this.results
                .map(
                    (result, index) => {

                        // SCREENSHOT LINKS

                        let screenshotHTML =
                            '—';


                        if (
                            result.screenshots.length
                        ) {

                            screenshotHTML =
                                result.screenshots
                                    .map(
                                        (
                                            screenshot,
                                            screenshotIndex
                                        ) => {

                                            return `
                                                <a
                                                    href="${screenshot.path}"
                                                    target="_blank"
                                                >
                                                    📷 Screen ${screenshotIndex + 1}
                                                </a>
                                                <br>
                                            `;
                                        }
                                    )
                                    .join('');
                        }


                        // VIDEO

                        let videoHTML =
                            '—';


                        if (result.video) {

                            videoHTML = `
                                <video
                                    width="250"
                                    controls
                                >
                                    <source
                                        src="${result.video.path}"
                                        type="video/webm"
                                    >
                                </video>
                            `;
                        }


                        return `

                        <tr>

                            <td>
                                ${index + 1}
                            </td>


                            <td>
                                <strong>
                                    ${this.escape(
                                        result.testTitle
                                    )}
                                </strong>
                            </td>


                            <td>
                                ${this.escape(
                                    result.scenario
                                )}
                            </td>


                            <td>

                                <span class="
                                    status
                                    ${result.status.toLowerCase()}
                                ">

                                    ${result.status}

                                </span>

                            </td>


                            <td>

                                ${screenshotHTML}

                            </td>


                            <td>

                                ${videoHTML}

                            </td>


                            <td>

                                ${(
                                    result.duration / 1000
                                ).toFixed(2)} sec

                            </td>


                            <td class="error">

                                ${
                                    result.error
                                        ? this.escape(
                                            result.error
                                        )
                                        : '—'
                                }

                            </td>

                        </tr>

                        `;
                    }
                )
                .join('');


        // ====================================================
        // HTML
        // ====================================================

        const html = `

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>
    Playwright Automation Report
</title>


<style>

body {

    font-family:
        Arial,
        sans-serif;

    background:
        #f5f6f8;

    margin:
        30px;
}


h1 {

    margin-bottom:
        25px;
}


/* SUMMARY */

.summary {

    display:
        flex;

    gap:
        20px;

    margin-bottom:
        30px;
}


.card {

    background:
        white;

    padding:
        20px;

    border-radius:
        10px;

    min-width:
        140px;

    box-shadow:
        0 2px 8px
        rgba(0,0,0,0.08);
}


.card h3 {

    margin:
        0 0 10px 0;
}


.card p {

    font-size:
        28px;

    font-weight:
        bold;

    margin:
        0;
}


/* TABLE */

table {

    width:
        100%;

    border-collapse:
        collapse;

    background:
        white;
}


th {

    background:
        #222;

    color:
        white;

    padding:
        14px;

    text-align:
        left;
}


td {

    padding:
        14px;

    border-bottom:
        1px solid #ddd;

    vertical-align:
        middle;
}


tr:hover {

    background:
        #f5f5f5;
}


/* STATUS */

.status {

    padding:
        6px 12px;

    border-radius:
        6px;

    font-weight:
        bold;
}


.passed {

    background:
        #d4edda;

    color:
        #155724;
}


.failed {

    background:
        #f8d7da;

    color:
        #721c24;
}


.skipped {

    background:
        #fff3cd;

    color:
        #856404;
}


/* LINKS */

a {

    color:
        #0066cc;

    text-decoration:
        none;

    line-height:
        28px;
}


a:hover {

    text-decoration:
        underline;
}


.error {

    color:
        #b00020;

    max-width:
        300px;
}

</style>

</head>


<body>


<h1>
    Playwright Automation Report
</h1>


<!-- SUMMARY -->

<div class="summary">


    <div class="card">

        <h3>
            Total Tests
        </h3>

        <p>
            ${total}
        </p>

    </div>


    <div class="card">

        <h3>
            Passed
        </h3>

        <p>
            ${passed}
        </p>

    </div>


    <div class="card">

        <h3>
            Failed
        </h3>

        <p>
            ${failed}
        </p>

    </div>


    <div class="card">

        <h3>
            Skipped
        </h3>

        <p>
            ${skipped}
        </p>

    </div>


</div>


<!-- TEST REPORT -->

<table>


<thead>

<tr>

    <th>
        #
    </th>

    <th>
        Test Title
    </th>

    <th>
        Scenario
    </th>

    <th>
        Status
    </th>

    <th>
        Screenshot
    </th>

    <th>
        Failure Video
    </th>

    <th>
        Duration
    </th>

    <th>
        Error
    </th>

</tr>

</thead>


<tbody>

${rows}

</tbody>


</table>


</body>

</html>
`;


        // -----------------------------------------------
        // SAVE REPORT
        // -----------------------------------------------

        fs.writeFileSync(

            path.join(
                this.reportFolder,
                'index.html'
            ),

            html
        );


        console.log(
            '\n======================================'
        );

        console.log(
            'CUSTOM PLAYWRIGHT REPORT GENERATED'
        );

        console.log(
            '======================================'
        );

        console.log(
            'Open: custom-report/index.html'
        );
    }


    // ========================================================
    // HTML ESCAPE
    // ========================================================

    escape(value) {

        if (!value) {
            return '';
        }


        return value

            .replace(
                /&/g,
                '&amp;'
            )

            .replace(
                /</g,
                '&lt;'
            )

            .replace(
                />/g,
                '&gt;'
            )

            .replace(
                /"/g,
                '&quot;'
            )

            .replace(
                /'/g,
                '&#039;'
            );
    }
}


export default CustomHTMLReporter;