import { test, expect} from '@playwright/test';
 
test('WebTable Testcase', async ({page})  => {

    await page.goto('https://app.thetestingacademy.com/playwright/webtable');

    await page.locator('tr:has(td:text("Rohan Mehta"))').locator('input').first().check();

    await page.waitForTimeout(5000);

});
