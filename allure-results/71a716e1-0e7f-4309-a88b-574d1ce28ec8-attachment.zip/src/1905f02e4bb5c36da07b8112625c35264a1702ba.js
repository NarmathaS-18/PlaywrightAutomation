import {  test,  expect,  testInfo } from '@playwright/test';


test('Print data from a webtable', async ({ page }, testInfo) => {

await page.goto('https://awesomeqa.com/webtable1.html');
const rows = awaitpage.locator('table[summary="Sample Table"] tbody tr');
const rowCount = await rows.count();

for(let i=0;i<rowCount-1;i++){
      
      const rowsData = await rows.nth(i).locator('td').allInnerTexts();
      console.log(`Row ${i + 1}:`, rowsData);
}
      await page.pause();
    


});